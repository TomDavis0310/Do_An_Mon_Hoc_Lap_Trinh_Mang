---
title: "Về tôi"
date: 2025-10-17
draft: false
showToc: false
showReadingTime: false
showShareButtons: false
showBreadCrumbs: false
---

## 👋 Xin chào!

Tôi là **Nguyễn Võ Xuân Dương**, sinh viên năm 3 ngành Công nghệ thông tin tại Đại học Công nghệ TP.HCM (HUTECH).

## 🎯 Về tôi

Tôi đam mê lập trình và phát triển phần mềm, đặc biệt quan tâm đến:

- **Lập trình Web Full-stack**
- **Java & Spring Boot**
- **JavaScript & Node.js**
- **Phát triển ứng dụng hiện đại**

## 📚 Blog này

Blog này là nơi tôi:

- ✍️ Chia sẻ kiến thức và kinh nghiệm trong quá trình học tập
- 📖 Ghi chép lại những gì tôi học được về lập trình
- 💡 Chia sẻ các bài hướng dẫn và tips hữu ích
- 🚀 Lưu trữ hành trình phát triển kỹ năng lập trình của bản thân

## 🛠️ Kỹ năng

### Ngôn ngữ lập trình
- Java
- JavaScript (ES6+)
- HTML/CSS
- SQL

### Frameworks & Tools
- Spring Boot
- Node.js
- Git & GitHub
- VS Code
- Maven

## 🎓 Học vấn

**Đại học Công nghệ TP.HCM (HUTECH)**
- Ngành: Công nghệ thông tin
- Năm học: Năm 3

## 🌱 Mục tiêu

Tôi đang nỗ lực phát triển kỹ năng để trở thành một **Full-stack Developer** chuyên nghiệp, với khả năng xây dựng các ứng dụng web hiện đại và quy mô lớn.

## 📫 Liên hệ

Bạn có thể kết nối với tôi qua:

- 📧 Email: [doduong0949447395@gmail.com](mailto:doduong0949447395@gmail.com)
- 💼 LinkedIn: [Nguyễn Võ Xuân Dương](https://linkedin.com/in/xuanduong)
- 👨‍💻 GitHub: [@TomDavis0310](https://github.com/TomDavis0310)
- 📘 Facebook: [Xuân Dương](https://www.facebook.com/duong.xuan.534908/)

---

*Cảm ơn bạn đã ghé thăm blog của tôi! Nếu có bất kỳ câu hỏi nào, đừng ngần ngại liên hệ nhé! 😊*
